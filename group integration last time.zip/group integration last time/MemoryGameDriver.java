  // driver class
class MemoryGameDriver {		
   public static void main (String argv[]){
      MemoryGame game = new MemoryGame(); 
      
   }
}

