import javax.swing.*;
import java.awt.*;
import java.awt.event.*;  


abstract class GameModelOne{

   abstract boolean takeTurn(int [] t);  
   abstract void gameOverStatus(int s);
   abstract ImageIcon getImage(int i);
   abstract int getRows();
   abstract int getCols(); 

   
   
}// class