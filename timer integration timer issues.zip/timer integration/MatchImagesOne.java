import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 
import java.util.*;
import javax.swing.JOptionPane;
import java.util.ArrayList; 

class MatchImagesOne extends GameModelOne{

   boolean match = false;
   boolean gos = false;
   boolean winner = false;
   String status = "";
   int ROWS = 4;
   int COLS = 4;
   private ImageIcon [] images = new ImageIcon[16];
   int successes = 0;
   int turn1 = -1;
   final int SIZE = 16; 
   final long twoMinutes = 120000; 
   
   MatchImagesOne(){
      
      images[0] = new ImageIcon("michelle1.jpg"); 
      images[1] = new ImageIcon("michelle2.jpg");
      images[2] = new ImageIcon("chyenne1.jpg");
      images[3] = new ImageIcon("c.jpg");
      images[4] = new ImageIcon("marilyn1.jpg");
      images[5] = new ImageIcon("marilyn2.jpg");
      images[6] = new ImageIcon("maxine1.jpg");
      images[7] = new ImageIcon("maxine2.png");
      images[8] = new ImageIcon("michelle1.jpg"); 
      images[9] = new ImageIcon("michelle2.jpg");
      images[10] = new ImageIcon("chyenne1.jpg");
      images[11] = new ImageIcon("c.jpg");
      images[12] = new ImageIcon("marilyn1.jpg");
      images[13] = new ImageIcon("marilyn2.jpg");
      images[14] = new ImageIcon("maxine1.jpg");
      images[15] = new ImageIcon("maxine2.png");
      
      //randomize the images
      ArrayList<ImageIcon> imageList = new ArrayList<ImageIcon>(Arrays.asList(images));
      Collections.shuffle(imageList);
      for( int i=0;i<imageList.size();i++){
         images[i] = imageList.get(i);
         }//for
   
   }//MatchImages Constructor
   
   int getRows(){
      return(ROWS);
   }//getRows
   int getCols(){
      return(COLS);
   }//getCols
   int getSize(){
      return(SIZE);
   }// getSize
      
   public String isMatch(boolean match){
      if(match == true){
         status = "It's a match!";
      }
      else{
         status = "Try again";
      }
      return(status);
   }//end isMatch
      
  /* void display(){}; //take care of this */  
   
   public ImageIcon getImage(int i){
      if(i>=0 && i<SIZE)
         return(images[i]); 
      else
         return(images[0]); 
   }//end ImageIcon

         
   public boolean takeTurn (int [] sources){
      String imageName1 = images[sources[0]].toString();
      String imageName2 = images[sources[1]].toString();
      if (imageName1 == imageName2){
         match = true;
      }
      else{
         match = false;
      }//close else
      return(match);
   
   }//takeTurn-made a boolean, because this is where we are comparing images for match status
   JLabel clock;
   public JPanel Countdown(){ 
   
      final java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("mm : ss"); 
      clock = new JLabel(sdf.format(new Date(twoMinutes)),JLabel.CENTER);
      clock.setFont(new Font("Comic Sans", Font.BOLD, 16)); 
      int x = 0; 
      
       
      JPanel jp = new JPanel();
           jp.add(clock); 
      jp.setBackground(new Color(174, 142, 206));
     
      return (jp);
   }//JPanel countdown
 
   
   public boolean gameOverStatus(int successes){
   
      if(successes == (SIZE/2)) {  
       //add a pop-up with end of game
       //.stop();
         JOptionPane.showMessageDialog(null, "Congrats! You found all of the matches.", "Winner", JOptionPane.INFORMATION_MESSAGE);
         return( true);
      }//else if
      else
         return(false); 
   
   }//end gameOverStatus

}//class
