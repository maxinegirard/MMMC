 import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 
//import java.util.*;
import javax.swing.JOptionPane;
import java.util.ArrayList; 


class TAL extends Timer implements ActionListener{
 //al =          new ActionListener(){ 
 
   long x = 120000 - 1000; 
   public void actionPerformed(ActionEvent ae){ 
      clock.setText(sdf.format(new Date(x))); 
      x -= 1000;} 
   
}