import javax.swing.*;
import java.awt.*;
import java.awt.event.*;  


abstract class GameModelOne{

   abstract boolean takeTurn(int [] t);  
   abstract boolean gameOverStatus(int successes);
   abstract ImageIcon getImage(int i);
   abstract int getRows();
   abstract int getCols(); 
   //abstract void display(); 
   //abstract String reportWinner(); 
   
   
}// class