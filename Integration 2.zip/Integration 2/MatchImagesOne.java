import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 
import java.util.*;
import javax.swing.JOptionPane;
//import java.util.ArrayList<E>; 

class MatchImagesOne extends GameModelOne{

   
   boolean match = false;
   boolean gos = false;
   boolean winner = false;
   String status = "";
   int ROWS = 4;
   int COLS = 4;
   private ImageIcon [] images = new ImageIcon[16];
   int successes = 0;
   int turn1 = -1;
   final int SIZE = 16; 
   
   MatchImagesOne(){
      //not random, to test
      
      
      /*commented out to debug, not random
      ArrayList<ImageIcon> imageList = new ArrayList<ImageIcon>(Arrays.asList(images));
      Collections.shuffle(imageList);
      // put images back in the plain [] array
      for( int i=0;i<imageList.size();i++)
         images[i] = imageList.get(i);
      commented out to debug*/
      
      images[0] = new ImageIcon("michelle1.jpg"); 
      images[1] = new ImageIcon("michelle2.jpg");
      images[2] = new ImageIcon("chyenne1.jpg");
      images[3] = new ImageIcon("c.jpg");
      images[4] = new ImageIcon("marilyn1.jpg");
      images[5] = new ImageIcon("marilyn2.jpg");
      images[6] = new ImageIcon("maxine1.jpg");
      images[7] = new ImageIcon("maxine2.png");
      images[8] = new ImageIcon("michelle1.jpg"); 
      images[9] = new ImageIcon("michelle2.jpg");
      images[10] = new ImageIcon("chyenne1.jpg");
      images[11] = new ImageIcon("c.jpg");
      images[12] = new ImageIcon("marilyn1.jpg");
      images[13] = new ImageIcon("marilyn2.jpg");
      images[14] = new ImageIcon("maxine1.jpg");
      images[15] = new ImageIcon("maxine2.png");

   }//MatchImages Constructor
   
   int getRows(){
      return(ROWS);
      }
   int getCols(){
      return(COLS);
      }
   int getSize(){
      return(SIZE);
   }// getSize
  
      
  public ImageIcon get(int i){ 
      return(images[i]); 
      }  //not sure why we need this one....?   
      
   public boolean gameOverStatus(int successes){
      if(successes == (SIZE/2)) {  
       //add a pop-up with end of game
      JOptionPane.showMessageDialog(null, "Congrats! You found all of the matches.", "End of game", JOptionPane.INFORMATION_MESSAGE);
         return( true);
         }//if
      else
         return(false); 
   }//end gameOverStatus
   
   public String isMatch(boolean match){
       if(match == true){
       status = "it's a match";
       }
       else{
       status = "this is not a match";
       }
       return(status);
       }//end isMatch
      
   void display(){};    
   
   public ImageIcon getImage(int i){
      if(i>=0 && i<SIZE)
         return(images[i]); 
      else
         return(images[0]); 
         }//end ImageIcon

         
    public boolean takeTurn (int [] sources){
      String imageName1 = images[sources[0]].toString();
      String imageName2 = images[sources[1]].toString();
      if (imageName1 == imageName2){
      match = true;
      
      }
      else{
      match = false;
      }//close else
      return(match);
   
 
}//takeTurn

}//class
