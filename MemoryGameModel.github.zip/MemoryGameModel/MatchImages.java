import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 
import java.util.*; 

class MatchImages{

   private ImageIcon [] images = new ImageIcon[16];
   final int SIZE = 16; 
   
   MatchImages(){
      //not random, to test
      images[0] = new ImageIcon("michelle1.jpg"); 
      images[1] = new ImageIcon("michelle2.jpg");
      images[2] = new ImageIcon("chyenne1.jpg");
      images[3] = new ImageIcon("chyenne2.jpg");
      images[4] = new ImageIcon("marilyn1.jpg");
      images[5] = new ImageIcon("marilyn2.jpg");
      images[6] = new ImageIcon("maxine1.jpg");
      images[7] = new ImageIcon("maxine2.png");
      /* I couldn't get maxine's second photo to save as a jpg- I didn't try very hard...will fix later*/
      /* need other pictures, not matching ones to fill out the rest of the grid*/
      
   }
   
   int getSize(){
      return(SIZE);
   }
   
   ImageIcon getImage(int i){
      if(i>=0 && i<SIZE)
         return(images[i]); 
      else
         return(images[0]); 
   }
}//class