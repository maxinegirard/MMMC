import javax.swing.*;
import java.awt.*;
import java.awt.event.*;  


abstract class GameModel extends MemoryGameModel{

   abstract int takeTurn(int t);
      /*if ImageIcon[i] != ImageIcon[i]
      count =  count + 1
      else
      count = count + 1
      success = success +1*/         
      
   abstract boolean gameOverStatus();
      /* boolean gos = false
      if 
      success == 4
      return(true)
      else
      return (false)*/
  
   abstract ImageIcon get(int i); 
     /*see maxine's example on github*/
  
   /*abstract int getRows();
   abstract int getCols(); 
   abstract void display();*/      
   
   abstract String reportWinner(); 
      /*if boolean gos == true
      return(winner)
      else
      return(not winner)*/  
   
}// class